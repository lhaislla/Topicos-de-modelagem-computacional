/* --- Generated the 2/10/2019 at 10:19 --- */
/* --- heptagon compiler, version 1.03.00 (compiled thu. may. 3 2:35:29 CET 2018) --- */
/* --- Command line: /usr/local/bin/heptc -target c -target z3z -s task lamp1.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "lamp1_types.h"

Lamp1__st_1 Lamp1__st_1_of_string(char* s) {
  if ((strcmp(s, "St_1_On")==0)) {
    return Lamp1__St_1_On;
  };
  if ((strcmp(s, "St_1_Off")==0)) {
    return Lamp1__St_1_Off;
  };
}

char* string_of_Lamp1__st_1(Lamp1__st_1 x, char* buf) {
  switch (x) {
    case Lamp1__St_1_On:
      strcpy(buf, "St_1_On");
      break;
    case Lamp1__St_1_Off:
      strcpy(buf, "St_1_Off");
      break;
    default:
      break;
  };
  return buf;
}

Lamp1__st Lamp1__st_of_string(char* s) {
  if ((strcmp(s, "St_On")==0)) {
    return Lamp1__St_On;
  };
  if ((strcmp(s, "St_Off")==0)) {
    return Lamp1__St_Off;
  };
}

char* string_of_Lamp1__st(Lamp1__st x, char* buf) {
  switch (x) {
    case Lamp1__St_On:
      strcpy(buf, "St_On");
      break;
    case Lamp1__St_Off:
      strcpy(buf, "St_Off");
      break;
    default:
      break;
  };
  return buf;
}

