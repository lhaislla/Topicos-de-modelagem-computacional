/* --- Generated the 2/10/2019 at 10:19 --- */
/* --- heptagon compiler, version 1.03.00 (compiled thu. may. 3 2:35:29 CET 2018) --- */
/* --- Command line: /usr/local/bin/heptc -target c -target z3z -s task lamp1.ept --- */

#ifndef _MAIN_H
#define _MAIN_H

#include "lamp1.h"
#endif // _MAIN_H
